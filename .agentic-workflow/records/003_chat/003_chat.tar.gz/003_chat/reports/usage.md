# Selected implementation usage

Null means unavailable. Known subtotals exclude missing measurements. Scope and omissions are in usage.json.

| Metric | Total | Known subtotal | Measured records | Missing records |
|---|---:|---:|---:|---:|
| input_tokens | unavailable | 22015723 | 328 | 0 |
| cached_input_tokens | unavailable | 21414528 | 328 | 0 |
| cache_write_input_tokens | unavailable | 0 | 328 | 0 |
| uncached_input_tokens | unavailable | 601195 | 328 | 0 |
| output_tokens | unavailable | 98376 | 328 | 0 |
| reasoning_output_tokens | unavailable | 24941 | 328 | 0 |
| total_tokens | unavailable | 22114099 | 328 | 0 |

## By task

| Group | Total tokens | Known subtotal | Missing records | Tools |
| --- | --- | --- | --- | --- |
| 01_api | unavailable | 723473 | 0 | 17 |
| 02_python_client | unavailable | 6506613 | 0 | 94 |
| 03_rust_client | unavailable | 4967598 | 0 | 57 |
| orchestration | unavailable | 8456555 | 0 | 112 |
| validation | unavailable | 1459860 | 0 | 23 |

Attribution omissions: 0 events; 3 diagnostics.

## By agent_run

| Group | Total tokens | Known subtotal | Missing records | Tools |
| --- | --- | --- | --- | --- |
| codex:01a1be44-b400-7bd1-a5be-f842a6d57d96 | unavailable | 8456555 | 0 | 112 |
| codex:01a1be45-83f6-7f61-8a7b-0742bccb3f51 | unavailable | 723473 | 0 | 17 |
| codex:01a1be47-eb4c-74e0-bdcc-235b718fda72 | unavailable | 4620420 | 0 | 55 |
| codex:01a1be48-12c8-7b60-8f3b-812a70aa4415 | unavailable | 4269977 | 0 | 43 |
| codex:01a1be50-fe1f-74f3-a6a7-9be4921c4e6b | unavailable | 646359 | 0 | 14 |
| codex:01a1be52-33e2-7c03-8fe5-b20c9c077fca | unavailable | 697621 | 0 | 14 |
| codex:01a1be56-81e9-7863-a16d-0369925e0cc8 | unavailable | 792994 | 0 | 15 |
| codex:01a1be5a-97a2-7463-96ec-9ad141da521f | unavailable | 446840 | 0 | 10 |
| codex:01a1be5c-6e0a-73e3-bb76-4436fbb601e9 | unavailable | 1459860 | 0 | 23 |

Attribution omissions: 0 events; 3 diagnostics.

## By role

| Group | Total tokens | Known subtotal | Missing records | Tools |
| --- | --- | --- | --- | --- |
| implementer | unavailable | 9613870 | 0 | 115 |
| reviewer | unavailable | 2583814 | 0 | 53 |
| supervisor | unavailable | 8456555 | 0 | 112 |
| validator | unavailable | 1459860 | 0 | 23 |

Attribution omissions: 0 events; 3 diagnostics.

## By model

| Group | Total tokens | Known subtotal | Missing records |
| --- | --- | --- | --- |
| gpt-6-astra | unavailable | 8456555 | 0 |
| gpt-6.1-sol | unavailable | 13657544 | 0 |

Attribution omissions: 0 events; 14 diagnostics.

## By effort

| Group | Total tokens | Known subtotal | Missing records |
| --- | --- | --- | --- |
| high | unavailable | 12934071 | 0 |
| medium | unavailable | 9180028 | 0 |

Attribution omissions: 0 events; 14 diagnostics.

## By model_effort

| Group | Total tokens | Known subtotal | Missing records |
| --- | --- | --- | --- |
| gpt-6-astra, medium | unavailable | 8456555 | 0 |
| gpt-6.1-sol, high | unavailable | 12934071 | 0 |
| gpt-6.1-sol, medium | unavailable | 723473 | 0 |

Attribution omissions: 0 events; 14 diagnostics.

## By task_model_effort

| Group | Total tokens | Known subtotal | Missing records |
| --- | --- | --- | --- |
| 01_api, gpt-6.1-sol, medium | unavailable | 723473 | 0 |
| 02_python_client, gpt-6.1-sol, high | unavailable | 6506613 | 0 |
| 03_rust_client, gpt-6.1-sol, high | unavailable | 4967598 | 0 |
| orchestration, gpt-6-astra, medium | unavailable | 8456555 | 0 |
| validation, gpt-6.1-sol, high | unavailable | 1459860 | 0 |

Attribution omissions: 0 events; 14 diagnostics.

## By tool

| Group | Observed calls | Outcomes | Observed seconds | Untimed |
| --- | --- | --- | --- | --- |
| exec | 214 | {'returned': 214} | 215.99899578094482 | 0 |
| followup_task | 2 | {'returned': 2} | 0.05200004577636719 | 0 |
| send_message | 43 | {'returned': 43} | 1.5940005779266357 | 0 |
| spawn_agent | 8 | {'returned': 8} | 0.28599977493286133 | 0 |
| wait_agent | 36 | {'returned': 36} | 1085.308999300003 | 0 |

Attribution omissions: 0 events; 14 diagnostics.

## By task_tool

| Group | Observed calls | Outcomes | Observed seconds | Untimed |
| --- | --- | --- | --- | --- |
| 01_api, exec | 14 | {'returned': 14} | 26.03600001335144 | 0 |
| 01_api, send_message | 3 | {'returned': 3} | 0.08899998664855957 | 0 |
| 02_python_client, exec | 83 | {'returned': 83} | 61.52099895477295 | 0 |
| 02_python_client, send_message | 11 | {'returned': 11} | 0.5180008411407471 | 0 |
| 03_rust_client, exec | 50 | {'returned': 50} | 47.19299864768982 | 0 |
| 03_rust_client, send_message | 7 | {'returned': 7} | 0.41899991035461426 | 0 |
| orchestration, exec | 48 | {'returned': 48} | 48.93799924850464 | 0 |
| orchestration, followup_task | 2 | {'returned': 2} | 0.05200004577636719 | 0 |
| orchestration, send_message | 18 | {'returned': 18} | 0.5389997959136963 | 0 |
| orchestration, spawn_agent | 8 | {'returned': 8} | 0.28599977493286133 | 0 |
| orchestration, wait_agent | 36 | {'returned': 36} | 1085.308999300003 | 0 |
| validation, exec | 19 | {'returned': 19} | 32.31099891662598 | 0 |
| validation, send_message | 4 | {'returned': 4} | 0.029000043869018555 | 0 |

Attribution omissions: 0 events; 14 diagnostics.

## Native lineage

- codex:01a1be44-b400-7bd1-a5be-f842a6d57d96 → codex:01a1be45-83f6-7f61-8a7b-0742bccb3f51 (spawn)
- codex:01a1be44-b400-7bd1-a5be-f842a6d57d96 → codex:01a1be47-eb4c-74e0-bdcc-235b718fda72 (spawn)
- codex:01a1be44-b400-7bd1-a5be-f842a6d57d96 → codex:01a1be48-12c8-7b60-8f3b-812a70aa4415 (spawn)
- codex:01a1be44-b400-7bd1-a5be-f842a6d57d96 → codex:01a1be50-fe1f-74f3-a6a7-9be4921c4e6b (spawn)
- codex:01a1be44-b400-7bd1-a5be-f842a6d57d96 → codex:01a1be52-33e2-7c03-8fe5-b20c9c077fca (spawn)
- codex:01a1be44-b400-7bd1-a5be-f842a6d57d96 → codex:01a1be56-81e9-7863-a16d-0369925e0cc8 (spawn)
- codex:01a1be44-b400-7bd1-a5be-f842a6d57d96 → codex:01a1be5a-97a2-7463-96ec-9ad141da521f (spawn)
- codex:01a1be44-b400-7bd1-a5be-f842a6d57d96 → codex:01a1be5c-6e0a-73e3-bb76-4436fbb601e9 (spawn)

## Coverage diagnostics

- aggregate_snapshot_excluded: 11
- ambiguous_dispatch_turn: 3
