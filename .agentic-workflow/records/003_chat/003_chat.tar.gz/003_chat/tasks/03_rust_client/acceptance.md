# 03_rust_client — acceptance

- **Request, sources and scope:** Reconcile Rust client behavior under `specs/spec_chat/tasks/03_rust_client.md`, its shared client specification, and project failure logging requirements.
- **Prerequisites:** API task accepted; dependency order is `specs/spec_chat/task_order.md`.
- **Target and paths:** `apps/chat/rust-client/`; evidence in `runs/03_rust_client/implementation/`.
- **Contracts:** Public command, state, output and error contracts are `specs/spec_chat/contracts/cli.md`; wire and acknowledgment contracts are `contracts/websocket.md` and `contracts/storage.md`.

| Requirement ID | Source / contract | Check scenario and pass rule |
|---|---|---|
| R1 | CLI commands, client state and status | CLI tests exercise initial state, idempotent connect/disconnect, remembered login, state clearing, and local validation; status remains local and complete in all states. |
| R2 | CLI terminal presentation | Real PTY input uses `> `, output blocks have one blank line, status stays grouped, unsolicited events appear immediately, and unfinished text plus cursor survive event arrival. |
| R3 | Shared client behavior and message_received | Real WebSocket peers deliver named messages with preserved spaces, including self-send ordering; client displays `← name: text` and sends a fresh correlated acknowledgment with decode-time UTC timestamp. |
| R4 | CLI behavior and WebSocket envelope | CLI tests verify matched login/acceptance replies, malformed events, errors with available correlation IDs, and no acknowledgment status to sender. |
| R5 | Project logging and CLI terminal presentation | Rejected `/login`, unknown and invalid commands, missing username, server errors and operational failures emit exactly one readable stderr block with cause, correlation if available, and appropriate command/reconnect hints. |
| R6 | CLI connection behavior and WebSocket heartbeat | CLI tests exercise handshake responsiveness, graceful close, abrupt drop/loss, silent matching pong, retained heartbeat, no queued sends/retry/reconnection, and continued command input after loss. |
| R7 | Rust constraints | `cargo fmt --check`, `cargo clippy --all-targets -- -D warnings`, and `cargo test` pass; inspect Dockerfile for locked build and interactive binary with URL support. |

- **Shared/regression/final checks:** Extend existing behavior tests rather than duplicate their contract coverage; record PTY execution and scoped diff inspection.
- **Limits and decisions:** Fresh independent review must follow implementation; no production test hooks are allowed; real WebSocket peers isolate client behavior while assembled API/client verification belongs to Supervisor.
