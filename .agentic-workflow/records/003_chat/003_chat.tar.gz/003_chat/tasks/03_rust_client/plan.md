# 03_rust_client — plan

- **Request and scope:** Reconcile the existing Rust client against current specifications in plan-review mode; own only `apps/chat/rust-client/` and this task's records.
- **Acceptance:** [acceptance.md](acceptance.md).
- **Sources and dependencies:** `specs/spec_chat/project.md`, `tasks/03_rust_client.md`, `tasks/shared/client.md`, `contracts/{cli,websocket,storage}.md`, and `verification.md`; apply `agentic-workflow/policies/{GUIDELINES,CHECKS,MODELS}.md`; API prerequisite is accepted.
- **Approach:** Retain separate terminal, transport, protocol, and state modules; use an established line editor for interactive prompt restoration, keep piped output plain, decode notification sender names separately from stored messages, consolidate failures on stderr, and preserve existing lifecycle behavior.
- **Target and paths:** Rust binary under `apps/chat/rust-client/`; evidence under `.agentic-workflow/records/003_chat/runs/03_rust_client/implementation/`.
- **Checks:** Run Cargo formatting, Clippy, and tests; update existing public CLI scenarios for errors and notification display; run a real PTY scenario covering asynchronous event restoration and cursor position, grouped status, heartbeat silence, and reconnect guidance; inspect scoped diff.
- **Memory:** `.agentic-workflow/memory/index.md` contains only an API note, which is outside this task.
