# 02_python_client — acceptance

- **Request, sources and scope:** Reconcile `apps/chat/python-client/` against the current Python task, shared client specification, project failure rule, CLI, WebSocket and storage contracts.
- **Prerequisites:** `specs/spec_chat/task_order.md` declares accepted `01_api.md`.
- **Target and paths:** Python client source, tests, dependency lock and Dockerfile under `apps/chat/python-client/`; evidence under `runs/02_python_client/implementation/`.
- **Contracts:** Authoritative inputs are `specs/spec_chat/contracts/cli.md`, `contracts/websocket.md` and `contracts/storage.md`; preserve UUID, UTC, zero and null wire alternatives and request correlation.

| Requirement ID | Source / contract | Check scenario and pass rule |
|---|---|---|
| PY-CLI | CLI commands and state | Run all commands with disconnected, connecting, pending-login and logged-in states; verify idempotence, command hints, retained username/heartbeat and cleared authentication through subprocess behavior tests. |
| PY-WIRE | Shared client behavior and WebSocket events | Use a real WebSocket peer to verify fresh correlations, acceptance only after replies, sender-name notifications, exact text spacing, receive timestamps before acknowledgments and silent ping/pong. |
| PY-TERM | CLI terminal presentation | Run a real PTY with `> ` prompts, multiline status and unsolicited events; verify one blank line between blocks and preserved unfinished text/cursor by inserting text at the restored cursor and observing the request. |
| PY-ERROR | Project failure logging and CLI presentation | Trigger local, server, malformed-event, connection and terminal failures; verify one stderr error per failure, a readable cause and available correlation, no exception class names, correction hints and connection-loss advice. |
| PY-LIFE | CLI lifecycle and shared acceptance | Test graceful disconnect, abrupt drop, EOF/quit and remote loss; verify responsive CLI, no retries or automatic reconnect, and reconnect only after `/connect`. |
| PY-TOOLS | Python task constraints | Run `uv sync --frozen`, full pytest, `ruff check` and `ruff format --check`; inspect asyncio/aiohttp/Pydantic usage and Docker interactive entry point. |

- **Shared/regression/final checks:** Apply the client presentation and failure-logging scenarios in `specs/spec_chat/verification.md`; Supervisor owns assembled-app checks and fresh independent review.
- **Limits and decisions:** Use local real WebSocket peers and real child processes rather than mocks; record Docker execution availability separately.
