# 02_python_client — plan

- **Request and scope:** Reconcile the Python client in plan-review mode; own only `apps/chat/python-client/` and this task's records.
- **Acceptance:** [acceptance.md](acceptance.md).
- **Sources and dependencies:** Use `specs/spec_chat/project.md`, `tasks/02_python_client.md`, `tasks/shared/client.md`, all shared contracts and `verification.md`; API prerequisite is accepted by Supervisor.
- **Approach:** Add an established asynchronous line editor for TTY input and prompt restoration; preserve plain pipe input/output; add notification-only sender names; consolidate each failure into one readable stderr block; preserve module boundaries and lifecycle state.
- **Target and paths:** Update `apps/chat/python-client/`; save evidence under `runs/02_python_client/implementation/`.
- **Checks:** Run the complete pytest suite, Ruff lint and formatting checks; use real local aiohttp peers and PTYs for unsolicited output, mid-line cursor restoration, original message spacing, stderr routing, heartbeat and reconnect behavior; inspect the final diff.
- **Memory:** `.agentic-workflow/memory/index.md` has no client-specific note.
