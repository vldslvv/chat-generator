# Supervisor reconciliation evidence

- Scope: all three tasks in `specs/spec_chat/task_order.md`; existing candidate `apps/chat` at base revision `e8889f8`.
- Status: PASS; all selected tasks accepted after fresh task reviews and final independent assembled-app validation.
- Routing: coordination profile; host settings retained because session routing cannot change.
- Integration regression extends the existing real-process exchange scenario to assert sender names and exact leading, internal and trailing message spacing in both directions, plus self-delivery in either notification/acceptance order.
- Baseline: `uv run --project apps/chat/api pytest apps/chat/integration -q` failed at the new sender-name assertion: existing Rust output used a UUID instead of `← python_user:`.
- Test authoring gate: the visible cross-language behavior is the protected contract; real protocol interoperability and self-delivery ordering are distinct from component checks; no production test hooks or mocks added.
- Integration Ruff lint and formatting checks passed before component reconciliation.
- The test-audit skill's linked `/home/vv/docs/help/testing/writing-tests.md` was unavailable; its available authoring gates were applied.
- Docker daemon access initially denied by the execution sandbox; container verification remains pending.

## Current checks

- `cargo build --locked --manifest-path apps/chat/rust-client/Cargo.toml` passed after both client implementations froze.
- `uv run --project apps/chat/api pytest apps/chat/integration -q` passed the real-process cross-language and self-send scenario in 0.82 seconds.
- API and Python client Docker images built successfully with locked dependencies.
- The API container imported its installed app/server, exposed the `/ws` route and configured one worker.
- The Python container accepted piped `/status`, `/login bob`, `/connect` and `/quit`, showing grouped status and expected command hints with exit 0.
- Rust container build is in progress; both client reviews are in progress.

- Rust release container build passed with its locked dependencies.
- Both client images started in real container TTY sessions with `TERM=xterm-256color`, displayed `> `, ran `/status`, and exited through `/quit` with status 0.
- Rust TTY smoke additionally displayed the `/login bob` correction once; Python piped smoke covered the same error and missing remembered username.
- Container checks verify packaging and basic terminal startup; application PTY regressions own the asynchronous message/cursor behavior.

- Python image was rebuilt successfully after both reviewed lifecycle corrections, including the final closed-input EOF fix.
- Python fresh final review passed all 37 tests, tooling and both independent shutdown probes; Rust fresh review passed all 10 tests and supplementary peer scenarios.
- All application, integration and documentation writers are paused for final Validator `/root/validation`; execution records may continue to update.

## Final acceptance

- Final Validator PASS: `runs/validation/final/result.md`; 103 tests total and all required formatting/lint checks passed on the unchanged assembled candidate.
- Both Python review findings were corrected and independently rechecked; original failed evidence is retained.
- No implementation work, repair publication or user decision remains outstanding.
- Specifications and pre-existing unrelated untracked files were left unchanged.
- Final diff inspected; no whitespace errors.
- Usage reports: `reports/usage.md` and `reports/usage.json`; native unfinished-turn and excluded aggregate-snapshot diagnostics limit telemetry, not acceptance.
