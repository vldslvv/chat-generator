import asyncio, json, uuid
from datetime import datetime, timezone
import websockets

BIN = '/home/vv/assignment/chat-generator/apps/chat/rust-client/target/debug/chat-rust'

async def run():
    peers = asyncio.Queue()
    async def handler(peer):
        await peers.put(peer)
        await peer.wait_closed()
    async with websockets.serve(handler, '127.0.0.1', 0, ping_interval=None) as server:
        port = server.sockets[0].getsockname()[1]
        proc = await asyncio.create_subprocess_exec(BIN, '--url', f'ws://127.0.0.1:{port}/ws', stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        out=[]; err=[]
        async def until(stream, match, lines):
            while True:
                raw=await asyncio.wait_for(stream.readline(), 5)
                assert raw, (match, lines)
                line=raw.decode().rstrip('\n')
                lines.append(line)
                if match in line: return line
        async def output(match): return await until(proc.stdout, match, out)
        async def error(match): return await until(proc.stderr, match, err)
        async def cmd(text):
            proc.stdin.write((text+'\n').encode()); await proc.stdin.drain()
        async def login(command):
            await cmd(command)
            peer=await asyncio.wait_for(peers.get(),5)
            req=json.loads(await peer.recv())
            assert req['type']=='login' and req['data']=={'name':'alice'}
            await peer.send(json.dumps({'type':'login_ok','correlation_id':req['correlation_id'],'data':{'id':str(uuid.uuid4()),'name':'alice'}}))
            await output('✓ Logged in as alice')
            return peer
        try:
            await output('Chat ready.')
            peer=await login('/connect alice')
            await peer.send(json.dumps({'type':'error','data':{'message':'Uncorrelated server rejection'}}))
            assert await error('Uncorrelated server rejection')=='✗ Error: Uncorrelated server rejection'
            await cmd('/send alice   acceptance  first  ')
            req=json.loads(await peer.recv())
            assert req['data']['text']=='  acceptance  first  '
            uuid.UUID(req['correlation_id'])
            now=datetime.now(timezone.utc)
            sent=datetime.fromisoformat(req['data']['client_sent_at'].replace('Z','+00:00'))
            assert abs((now-sent).total_seconds())<2
            message={'id':str(uuid.uuid4()),'sender_id':str(uuid.uuid4()),'recipient_id':str(uuid.uuid4()),'text':req['data']['text'],'client_sent_at':req['data']['client_sent_at'],'server_received_at':now.isoformat(),'recipient_received_at':None,'server_ack_received_at':None}
            await peer.send(json.dumps({'type':'message_accepted','correlation_id':req['correlation_id'],'data':message}))
            await output('✓ Accepted '+message['id'])
            before=datetime.now(timezone.utc)
            await peer.send(json.dumps({'type':'message_received','data':dict(message,sender_name='alice')}))
            assert await output('← alice:')=='← alice:   acceptance  first  '
            ack=json.loads(await peer.recv())
            assert ack['type']=='ack' and ack['data']['message_id']==message['id']
            assert ack['correlation_id']!=req['correlation_id']
            uuid.UUID(ack['correlation_id'])
            decoded=datetime.fromisoformat(ack['data']['recipient_received_at'].replace('Z','+00:00'))
            assert before<=decoded<=datetime.now(timezone.utc)
            await peer.close(code=1000, reason='review shutdown')
            await output('Connection closed by server. Use /connect to reconnect')
            await output('Disconnected')
            await cmd('/status'); await output('Last heartbeat: never')
            assert 'Connection: disconnected\nSession: none\nUser: -' in '\n'.join(out)
            try:
                await asyncio.wait_for(peers.get(), .2)
                raise AssertionError('automatic reconnect')
            except TimeoutError: pass
            peer=await login('/connect')
            await cmd('/quit')
            await asyncio.wait_for(peer.wait_closed(),5)
            assert peer.close_code in (1000, 1005), peer.close_code
            assert await asyncio.wait_for(proc.wait(),5)==0
            remainder=(await proc.stderr.read()).decode()
            assert not remainder.strip(), remainder
            assert len([x for x in err if x.startswith('✗ Error:')])==1,err
            assert not any('✗ Error:' in x for x in out),out
            print('PASS: uncorrelated server error exactly once on stderr; acceptance-first self delivery preserves spaces; fresh ACK UUID and decode-time UTC; normal server close keeps CLI usable; no automatic reconnect; remembered manual reconnect; graceful quit.')
            print('\n'.join(out))
            print('stderr: '+repr(err))
        finally:
            if proc.returncode is None:
                proc.kill(); await proc.wait()

asyncio.run(run())
