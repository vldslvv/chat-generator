import asyncio
import sys
from uuid import uuid4

sys.path.insert(0, '/home/vv/assignment/chat-generator/apps/chat/python-client/tests')
from aiohttp import web
from test_cli import client, next_item, reply, server
from test_protocol import message_data


async def exercise():
    sockets = asyncio.Queue()
    requests = asyncio.Queue()

    async def handler(request):
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        login = await ws.receive_json()
        await ws.send_json(reply('login_ok', login, {'id': str(uuid4()), 'name': 'alice'}))
        await sockets.put(ws)
        async for frame in ws:
            await requests.put(frame.json())
        return ws

    async with server(handler) as url, client(url) as cli:
        await cli.command('/connect alice')
        ws = await next_item(sockets)
        await cli.until('Logged in as alice')
        await cli.command('/send alice first  self  ')
        send = await next_item(requests)
        await cli.command('/send alice second')
        print('overlap:', await cli.error_until('Send in progress'))
        message = {**message_data(), 'text': send['data']['text']}
        # Deliver the self notification before acceptance, as the contract permits.
        await ws.send_json({'type': 'message_received', 'data': {**message, 'sender_name': 'alice'}})
        print('self notification:', repr(await cli.until('← alice: first  self  ')))
        ack = await next_item(requests)
        print('ack:', ack['type'], ack['data']['message_id'] == message['id'])
        await ws.send_json(reply('message_accepted', send, message))
        print('acceptance:', repr(await cli.until('✓ Accepted')))

    async with server(handler) as url, client(url) as cli:
        await cli.command('/connect alice')
        ws = await next_item(sockets)
        await cli.until('Logged in as alice')
        cli.process.stdout._transport.close()
        await ws.close()
        await cli.error_until('WebSocket connection lost')
        await cli.command('/help')
        await asyncio.sleep(0.15)
        print('after disconnected output broke:', repr(cli.diagnostics))
        await cli.command('/connect alice')
        await next_item(sockets)
        await asyncio.sleep(0.15)
        print('after reconnect:', repr(cli.diagnostics))
        # client context issues /quit and waits for normal exit.


asyncio.run(exercise())
