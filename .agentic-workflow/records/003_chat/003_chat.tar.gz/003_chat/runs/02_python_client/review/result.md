# Python client independent review — result

- **Scope and candidate:** Reviewed the paused `apps/chat/python-client/` working tree at base revision `e8889f80ebfb08c38949d5a24fd7f52c4e3f7625`, including uncommitted reconciliation and new interactive test. Read the [project](../../../../../../specs/spec_chat/project.md), [Python task](../../../../../../specs/spec_chat/tasks/02_python_client.md), [shared client requirements](../../../../../../specs/spec_chat/tasks/shared/client.md), all shared contracts and [verification](../../../../../../specs/spec_chat/verification.md) before acceptance and candidate inspection. Derived checks for command/state transitions, wire payloads, timestamps, sender names, spacing, real terminal restoration, errors and connection lifecycle. Then read the assigned acceptance document. Kept candidate files unchanged; unrelated Rust work was outside the boundary.
- **Role and status:** Reviewer; **FAIL**, because the disconnect notification can escape terminal-failure reporting and produce an unhandled task traceback.
- **Model routing:** Used `agentic-workflow/policies/MODELS.md`; no project override exists. Selected `careful`, the Reviewer default (`gpt-6.1-sol`, high reasoning). Current session settings cannot be changed; observed model/reasoning and usage counters are unavailable.

## Finding

**P2 — Report terminal failure while printing the disconnect notification.**

The [disconnect output in `connection_loop`](../../../../../../apps/chat/python-client/chat_client/cli.py#L93) runs in `finally`, outside the `OutputFailure` handler at line 67. If stdout closes after login and the peer then closes the connection, printing `Disconnected` raises `OutputFailure` out of the background task. Reconnecting replaces the old task reference and stderr receives `Task exception was never retrieved`, a traceback, `BrokenPipeError` and `OutputFailure`. The terminal failure does not receive a readable `✗ Error:` diagnostic. This violates the [project failure rule](../../../../../../specs/spec_chat/project.md) and the [CLI terminal presentation rules](../../../../../../specs/spec_chat/contracts/cli.md#terminal-presentation): report each operational failure once with its cause and omit exception class names.

Reproduce from `apps/chat/python-client/`:

```sh
uv run python /home/vv/assignment/chat-generator/.agentic-workflow/records/003_chat/runs/02_python_client/review/probe.py
```

The saved [probe](probe.py) runs a real CLI subprocess against a local aiohttp WebSocket peer. Its second scenario logs in, closes the parent's stdout read end, closes the server socket, sends `/help`, then reconnects. The [captured output](probe.log) contains the unhandled task diagnostic and fails the existing subprocess helper's no-traceback assertion. That final assertion is the probe failure, not an application-generated harness traceback. Catch and report failures from this final output path, retaining any available correlation before resetting it; add one regression at the real subprocess boundary for this uncovered path.

## Checks and coverage

| Check | Result | Evidence and coverage |
|---|---|---|
| `uv sync --frozen` | PASS | Exit 0; 25 packages checked. |
| `uv run pytest -q` | PASS | Independently executed all 35 tests; 35 passed in 3.35 seconds. |
| `uv run ruff check` | PASS | Exit 0; all checks passed. |
| `uv run ruff format --check` | PASS | Exit 0; 13 files formatted. |
| `git diff --check -- apps/chat/python-client` | PASS | Exit 0. |
| Real terminal and WebSocket behavior | PASS | Existing executed tests verify `> `, grouped status, blank separation, unchanged completed lines, preserved partial input and cursor by subsequent insertion observed on the wire, independent stderr, fresh UUIDs, timestamps, exact spaces, silent ping/pong, pending-login status, local/server errors, malformed frames, graceful close, abrupt drop and manual reconnection. |
| Additional self-send/order check | PASS | First probe scenario delivers a sender-named self notification before acceptance, preserves trailing/repeated spaces, and receives an acknowledgment for the same message ID. |
| Disconnect-output failure | FAIL | Second probe scenario and `probe.log`, as described above. |
| Docker execution | NOT_RUN | `docker info` failed with socket permission denied. Supervisor reports packaging/startup passed separately; this review does not claim independent container execution. |

The tests use real local network peers, real processes and a PTY rather than mocks supplying asserted behavior. Transport-only subprocess checks cover distinct send/pong/close failure risks; typed decoder tests protect independent wire types. No test-only production seam was found. The output-failure tests cover foreground output and login-reply output, but miss the final disconnect notification. EOF was not separately exercised by this review; `/quit` and connection cleanup were exercised. Assembled Python/Rust/API validation remains the Supervisor's responsibility. No other actionable finding is asserted.

- **Independent checks:** Fresh reviewer context; excluded plans, memory, conversations and implementation narratives. Permitted implementation check log was read only after requirements; all required local checks above were executed independently. No candidate change was observed inside the paused Python boundary.
- **Next:** Repair the finding and repeat the affected fresh independent review before acceptance.
