"""Independent public-process checks for explicit shutdown and EOF."""

import asyncio
import sys
from uuid import uuid4

sys.path.insert(0, '/home/vv/assignment/chat-generator/apps/chat/python-client/tests')
from aiohttp import web
from test_cli import Terminal, next_item, reply, server


async def exercise(command):
    logins = asyncio.Queue()
    sends = asyncio.Queue()
    closures = asyncio.Queue()

    async def handler(request):
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        login = await ws.receive_json()
        await logins.put(login)
        await ws.send_json(reply('login_ok', login, {'id': str(uuid4()), 'name': 'alice'}))
        async for frame in ws:
            await sends.put(frame.json())
        await closures.put(ws.close_code)
        return ws

    async with server(handler) as url:
        process = await asyncio.create_subprocess_exec(
            sys.executable, '-m', 'chat_client', '--url', url,
            stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        cli = Terminal(process)
        errors = asyncio.create_task(cli.capture_errors())
        try:
            await cli.until('Chat client ready')
            await cli.command('/connect alice')
            await next_item(logins)
            await cli.until('Logged in as alice')
            if command is not None:
                await cli.command('/send bob pending')
                pending = await next_item(sends)
                process.stdout._transport.close()
                await cli.command(command)
                diagnostic = await cli.error_until('Terminal output failed')
                assert 'Broken pipe' in diagnostic
                assert pending['correlation_id'] in diagnostic
                assert await next_item(closures) == (1006 if command == '/drop-connection' else 1000)
                await cli.command('/connect')
                assert (await next_item(logins))['data']['name'] == 'alice'
                # A new request proves the input loop and login work after failed output.
                await cli.command('/send bob fresh')
                assert (await next_item(sends))['data']['text'] == 'fresh'
            if command is None:
                process.stdin.close()
            else:
                await cli.command('/quit')
            async with asyncio.timeout(4):
                exit_code = await process.wait()
            await errors
            print(f'{command or "EOF while connected"}: exit={exit_code}; stderr={cli.diagnostics!r}')
            assert exit_code == 0, (exit_code, cli.diagnostics)
            assert await next_item(closures) == 1000
            diagnostics = '\n'.join(cli.diagnostics)
            assert diagnostics.count('✗ Error:') == (1 if command else 0), diagnostics
            assert 'Traceback' not in diagnostics
            assert 'never retrieved' not in diagnostics
            assert 'OutputFailure' not in diagnostics
            print(f'{command or "EOF while connected"}: PASS; no unhandled task')
        finally:
            if process.returncode is None:
                process.kill()
                await process.wait()
            await errors


async def main():
    failures = []
    for command in [None, '/disconnect', '/drop-connection']:
        try:
            await exercise(command)
        except AssertionError as error:
            failures.append((command, str(error)))
    if failures:
        raise SystemExit(f'Failed checks: {failures!r}')


asyncio.run(main())
