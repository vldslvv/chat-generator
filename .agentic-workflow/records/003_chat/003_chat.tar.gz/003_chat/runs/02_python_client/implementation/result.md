# Python client implementation — result

- **Scope and candidate:** Reconcile `apps/chat/python-client/` against `specs/spec_chat/project.md`, `tasks/02_python_client.md`, `tasks/shared/client.md`, `contracts/*.md` and `verification.md`; apply `tasks/02_python_client/acceptance.md` in this implementation record.
- **Role and status:** Implementer, plan-review; BLOCKED by `INDEPENDENT_REVIEW_NOT_RUN`; source is paused and ready for Supervisor-coordinated fresh review.
- **Model routing:** Use `agentic-workflow/policies/MODELS.md`; careful profile for interactive terminal lifecycle; requested `gpt-6.1-sol` with high reasoning; current host model/reasoning observations are unavailable and no session controls were exposed.
- **Checks:** [checks.log](checks.log) records `uv sync --frozen`, full pytest (35 passed), Ruff lint, Ruff formatting and scoped diff whitespace checks, all with exit 0.
- **Checks:** PY-TERM uses a real child process, PTY and pyte terminal emulator to verify the prompt, grouped status fields, blank lines, unchanged completed output and an incoming event above restored unfinished input; insertion at the restored cursor produces the exact expected WebSocket request.
- **Checks:** The same PTY check captures stderr separately and verifies a correlated server error leaves input and cursor intact while appearing only on stderr.
- **Checks:** PY-WIRE and PY-LIFE use real local aiohttp peers and client subprocesses for original text spacing, sender display, receipt timestamps, correlations, heartbeat responses, reconnect state, graceful closure and abrupt termination.
- **Checks:** PY-ERROR checks stderr-only command hints, omitted exception class names, exactly one error for each tested network failure, and retained correlation when displaying a server reply fails.
- **Findings and resolutions:** Added sender-name notification decoding and display, login confirmation, asynchronous terminal editing, blank output blocks, readable stderr errors, command corrections and reconnect advice; preserved plain pipe output and existing wire alternatives.
- **Findings and resolutions:** [baseline.log](baseline.log) records three intended failures against original `HEAD` source: absent interactive prompt, rejected sender-name notification and missing actionable unknown-command hint.
- **Findings and resolutions:** [baseline-output-failure.log](baseline-output-failure.log) records the original failure to retain the correlation ID on a broken reply display; the repaired regression passes.
- **Coverage and blockers:** Fresh independent review is pending; Supervisor owns Docker execution, assembled Python/Rust/API integration and acceptance.
- **Coverage and blockers:** No mocks or production test hooks were added; real local WebSocket peers replace only the external server so terminal and transport failures can be controlled independently.
- **Coverage and blockers:** The new tests add distinct PTY rendering and live reply-display failure coverage; existing protocol, lifecycle and transport tests remain the primary owners of their contracts.
- **Independent checks:** NOT_RUN; Supervisor will coordinate the fresh review while this source remains unchanged.
- **Usage:** Per-worker usage counters are unavailable; implementation-level reports remain under `.agentic-workflow/records/003_chat/reports/`.
- **Memory:** `.agentic-workflow/memory/index.md` contains no client-specific entry.
