# Python client correction — result

- **Scope and candidate:** Correct the Python client finding from [fresh review](../review/result.md); change only `apps/chat/python-client/chat_client/cli.py` and the existing subprocess regression in `tests/test_cli.py`.
- **Role and status:** Implementer, plan-review; correction checks pass; BLOCKED by `INDEPENDENT_REVIEW_NOT_RUN` until fresh re-review; source is paused.
- **Model routing:** Retain `agentic-workflow/policies/MODELS.md` careful profile for terminal lifecycle; requested `gpt-6.1-sol` with high reasoning; observed session model/reasoning and usage counters remain unavailable.
- **Findings and resolutions:** Catch `OutputFailure` from the final disconnect notification and retain the outstanding request correlation before resetting state; emit one readable terminal-failure error instead of leaving a failed background task.
- **Checks:** [pre-fix-probe.log](pre-fix-probe.log) reproduces the review probe's unhandled task traceback before correction; [post-fix-probe.log](post-fix-probe.log) records the same probe passing with one readable terminal-output error and no task traceback after reconnection.
- **Checks:** Extend the existing output-failure subprocess test with a disconnect case that closes stdout after login, leaves a send outstanding, closes the peer, checks the error's request ID and reconnects with the remembered username; verify one terminal-output error and no unhandled-task diagnostic.
- **Checks:** [pre-fix-regression.log](pre-fix-regression.log) records the disconnect case failing against a temporary copy with only this correction removed; the corrected two-case test passes.
- **Checks:** [checks.log](checks.log) records `uv sync --frozen`, all 36 pytest cases, Ruff lint, Ruff formatting and scoped diff checks, all with exit 0; the full suite includes the real PTY test.
- **Checks:** Retain real subprocesses and local WebSocket peers; no mocks, production test hooks or duplicate regression tests were added.
- **Findings and resolutions:** The first test extension attempted reconnect before login-output failure cleanup completed; restrict the reconnect assertion to the reviewed disconnect path and retain that initial attempt in [initial-test-attempt.log](initial-test-attempt.log).
- **Coverage and blockers:** No other review finding was asserted; Supervisor owns fresh re-review, Docker execution and assembled-app validation.
- **Independent checks:** The prior review remains FAIL until a fresh reviewer checks the correction; no reviewer was spawned by the implementer.
