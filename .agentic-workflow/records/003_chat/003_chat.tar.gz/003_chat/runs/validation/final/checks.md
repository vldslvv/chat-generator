# Final validation checks

Derived from the original selected specification before acceptance or candidate inspection.

- API protocol and state: exercise valid login/send/ack, invalid and repeated requests, immutable state on rejection, timestamp fallback and server receipt times, idempotent acknowledgments, notification-only sender_name, session cleanup, one delivery attempt, retained records, empty restart, standard heartbeat timing and stderr correlation.
- Python and Rust public behavior: exercise commands, status, idempotence, remembered identity, send and receive with original spaces including self delivery, acknowledgment wire types and UTC receipt time, unique correlations, silent heartbeat and lifecycle reset, usable CLI after failures, no retries or reconnect, and each failure once on stderr with cause and correlation.
- Interactive terminal: inspect real PTY behavior for prompt, output blocks, unsolicited events during unfinished input, cursor restoration and clean quit/EOF.
- Tooling and architecture: run pytest/Ruff for API and Python; cargo test/fmt/clippy for Rust; inspect required dependencies, lockfiles, Docker entrypoint configuration and separate public module boundaries.
- Assembled app: run the real integration harness against all final components and assess the suite assertions against the source scenarios.
- Container builds and Docker runtime checks will remain independently NOT_RUN per assignment; separate Supervisor evidence does not become independent validation evidence.

Sources: specs/spec_chat/project.md; task_order.md; tasks/01_api.md; tasks/02_python_client.md; tasks/03_rust_client.md; tasks/shared/client.md; contracts/cli.md; contracts/websocket.md; contracts/storage.md; verification.md; agentic-workflow/policies/GUIDELINES.md and CHECKS.md.
