# Selected implementation usage

Null means unavailable. Known subtotals exclude missing measurements. Scope and omissions are in usage.json.

| Metric | Total | Known subtotal | Measured records | Missing records |
|---|---:|---:|---:|---:|
| input_tokens | 31812760 | 31812760 | 454 | 0 |
| cached_input_tokens | 31086848 | 31086848 | 454 | 0 |
| cache_write_input_tokens | 0 | 0 | 454 | 0 |
| uncached_input_tokens | 725912 | 725912 | 454 | 0 |
| output_tokens | 162315 | 162315 | 454 | 0 |
| reasoning_output_tokens | 51439 | 51439 | 454 | 0 |
| total_tokens | 31975075 | 31975075 | 454 | 0 |

## By task

| Group | Total tokens | Known subtotal | Missing records | Tools |
| --- | --- | --- | --- | --- |
| 01_api | 6289484 | 6289484 | 0 | 92 |
| 02_python_client | 7323131 | 7323131 | 0 | 106 |
| 03_rust_client | 4364237 | 4364237 | 0 | 64 |
| orchestration | 12948981 | 12948981 | 0 | 132 |
| validation | 1049242 | 1049242 | 0 | 16 |

Attribution omissions: 0 events; 0 diagnostics.

## By agent_run

| Group | Total tokens | Known subtotal | Missing records | Tools |
| --- | --- | --- | --- | --- |
| codex:01a1be70-2c36-7530-8f85-5ad2fe59c02d | 12948981 | 12948981 | 0 | 132 |
| codex:01a1be70-f1a9-7d53-a954-db2a2fe62878 | 4699172 | 4699172 | 0 | 59 |
| codex:01a1be76-f5b2-70b0-b3d0-b2cc1b300cc2 | 612035 | 612035 | 0 | 12 |
| codex:01a1be7b-72e9-77e0-8225-b5f57e1ddaef | 603480 | 603480 | 0 | 13 |
| codex:01a1be7e-51bb-7ee0-943e-693d70e526f7 | 374797 | 374797 | 0 | 8 |
| codex:01a1be7f-eeee-76a2-9ae3-cd9d6b5826e8 | 4811523 | 4811523 | 0 | 59 |
| codex:01a1be80-198e-71e3-93a7-bab6b9c6a557 | 3441621 | 3441621 | 0 | 48 |
| codex:01a1be84-27bd-7cf3-aa9b-dc128f0d1a5d | 707963 | 707963 | 0 | 14 |
| codex:01a1be88-c691-7ee1-9484-2c5948cc20d4 | 1043788 | 1043788 | 0 | 18 |
| codex:01a1be8b-d097-7201-ba42-fde599f3567c | 922616 | 922616 | 0 | 16 |
| codex:01a1be8f-036c-77b0-bc3b-cbcc20ccdeb1 | 759857 | 759857 | 0 | 15 |
| codex:01a1be91-7e99-7753-9556-b49539dd0ed7 | 1049242 | 1049242 | 0 | 16 |

Attribution omissions: 0 events; 0 diagnostics.

## By role

| Group | Total tokens | Known subtotal | Missing records | Tools |
| --- | --- | --- | --- | --- |
| implementer | 12952316 | 12952316 | 0 | 166 |
| reviewer | 5024536 | 5024536 | 0 | 96 |
| supervisor | 12948981 | 12948981 | 0 | 132 |
| validator | 1049242 | 1049242 | 0 | 16 |

Attribution omissions: 0 events; 0 diagnostics.

## By model

| Group | Total tokens | Known subtotal | Missing records |
| --- | --- | --- | --- |
| gpt-6-astra | 12948981 | 12948981 | 0 |
| gpt-6.1-sol | 19026094 | 19026094 | 0 |

Attribution omissions: 0 events; 12 diagnostics.

## By effort

| Group | Total tokens | Known subtotal | Missing records |
| --- | --- | --- | --- |
| high | 19026094 | 19026094 | 0 |
| medium | 12948981 | 12948981 | 0 |

Attribution omissions: 0 events; 12 diagnostics.

## By model_effort

| Group | Total tokens | Known subtotal | Missing records |
| --- | --- | --- | --- |
| gpt-6-astra, medium | 12948981 | 12948981 | 0 |
| gpt-6.1-sol, high | 19026094 | 19026094 | 0 |

Attribution omissions: 0 events; 12 diagnostics.

## By task_model_effort

| Group | Total tokens | Known subtotal | Missing records |
| --- | --- | --- | --- |
| 01_api, gpt-6.1-sol, high | 6289484 | 6289484 | 0 |
| 02_python_client, gpt-6.1-sol, high | 7323131 | 7323131 | 0 |
| 03_rust_client, gpt-6.1-sol, high | 4364237 | 4364237 | 0 |
| orchestration, gpt-6-astra, medium | 12948981 | 12948981 | 0 |
| validation, gpt-6.1-sol, high | 1049242 | 1049242 | 0 |

Attribution omissions: 0 events; 12 diagnostics.

## By tool

| Group | Observed calls | Outcomes | Observed seconds | Untimed |
| --- | --- | --- | --- | --- |
| exec | 242 | {'returned': 242} | 248.38299751281738 | 0 |
| list_agents | 3 | {'returned': 3} | 0.22699999809265137 | 0 |
| send_message | 95 | {'returned': 95} | 5.044000148773193 | 0 |
| spawn_agent | 11 | {'returned': 11} | 0.55899977684021 | 0 |
| wait_agent | 59 | {'returned': 59} | 1919.469999551773 | 0 |

Attribution omissions: 0 events; 12 diagnostics.

## By task_tool

| Group | Observed calls | Outcomes | Observed seconds | Untimed |
| --- | --- | --- | --- | --- |
| 01_api, exec | 58 | {'returned': 58} | 80.14299869537354 | 0 |
| 01_api, send_message | 25 | {'returned': 25} | 1.803999900817871 | 0 |
| 01_api, spawn_agent | 3 | {'returned': 3} | 0.12199974060058594 | 0 |
| 01_api, wait_agent | 6 | {'returned': 6} | 198.65800023078918 | 0 |
| 02_python_client, exec | 63 | {'returned': 63} | 61.71299934387207 | 0 |
| 02_python_client, send_message | 26 | {'returned': 26} | 1.059999942779541 | 0 |
| 02_python_client, spawn_agent | 3 | {'returned': 3} | 0.11099982261657715 | 0 |
| 02_python_client, wait_agent | 14 | {'returned': 14} | 309.71399974823 | 0 |
| 03_rust_client, exec | 42 | {'returned': 42} | 22.79099941253662 | 0 |
| 03_rust_client, send_message | 10 | {'returned': 10} | 0.42600035667419434 | 0 |
| 03_rust_client, spawn_agent | 1 | {'returned': 1} | 0.012000083923339844 | 0 |
| 03_rust_client, wait_agent | 11 | {'returned': 11} | 413.22900009155273 | 0 |
| orchestration, exec | 65 | {'returned': 65} | 59.11200022697449 | 0 |
| orchestration, list_agents | 3 | {'returned': 3} | 0.22699999809265137 | 0 |
| orchestration, send_message | 32 | {'returned': 32} | 1.7450001239776611 | 0 |
| orchestration, spawn_agent | 4 | {'returned': 4} | 0.31400012969970703 | 0 |
| orchestration, wait_agent | 28 | {'returned': 28} | 997.8689994812012 | 0 |
| validation, exec | 14 | {'returned': 14} | 24.62399983406067 | 0 |
| validation, send_message | 2 | {'returned': 2} | 0.008999824523925781 | 0 |

Attribution omissions: 0 events; 12 diagnostics.

## Native lineage

- codex:01a1be70-2c36-7530-8f85-5ad2fe59c02d → codex:01a1be70-f1a9-7d53-a954-db2a2fe62878 (spawn)
- codex:01a1be70-2c36-7530-8f85-5ad2fe59c02d → codex:01a1be7f-eeee-76a2-9ae3-cd9d6b5826e8 (spawn)
- codex:01a1be70-2c36-7530-8f85-5ad2fe59c02d → codex:01a1be80-198e-71e3-93a7-bab6b9c6a557 (spawn)
- codex:01a1be70-2c36-7530-8f85-5ad2fe59c02d → codex:01a1be91-7e99-7753-9556-b49539dd0ed7 (spawn)
- codex:01a1be70-f1a9-7d53-a954-db2a2fe62878 → codex:01a1be76-f5b2-70b0-b3d0-b2cc1b300cc2 (spawn)
- codex:01a1be70-f1a9-7d53-a954-db2a2fe62878 → codex:01a1be7b-72e9-77e0-8225-b5f57e1ddaef (spawn)
- codex:01a1be70-f1a9-7d53-a954-db2a2fe62878 → codex:01a1be7e-51bb-7ee0-943e-693d70e526f7 (spawn)
- codex:01a1be7f-eeee-76a2-9ae3-cd9d6b5826e8 → codex:01a1be84-27bd-7cf3-aa9b-dc128f0d1a5d (spawn)
- codex:01a1be7f-eeee-76a2-9ae3-cd9d6b5826e8 → codex:01a1be88-c691-7ee1-9484-2c5948cc20d4 (spawn)
- codex:01a1be7f-eeee-76a2-9ae3-cd9d6b5826e8 → codex:01a1be8f-036c-77b0-bc3b-cbcc20ccdeb1 (spawn)
- codex:01a1be80-198e-71e3-93a7-bab6b9c6a557 → codex:01a1be8b-d097-7201-ba42-fde599f3567c (spawn)

## Coverage diagnostics

- aggregate_snapshot_excluded: 12
