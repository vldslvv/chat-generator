# Independent check selection

Chosen from original sources before reading acceptance or candidate code.

- Run both real-process language assignments in `make test-offline-delivery`, covering the seven-step scenario in [the source plan](../../../../../../specs/spec_chat/offline_delivery_test_plan.md#scenario-and-checks).
- Inspect API/storage ownership and run relevant public behavior checks for acceptance order, offline sender lookup, redelivery without acknowledgment, acknowledgment removal/idempotence, malformed requests, and failure logging under [the API source](../../../../../../specs/spec_chat/tasks/01_api.md).
- Inspect both client queue modules and run behavior checks for ownership, correlation, retention, explicit reconnect, terminal errors, and state lifecycle under [the CLI source](../../../../../../specs/spec_chat/contracts/cli.md).
- Inspect the shared runner for complete step-local matching, bounded waits, diagnostics, process lifetime, and dedicated demo cleanup under [the source plan](../../../../../../specs/spec_chat/offline_delivery_test_plan.md).
- Verify the real visual demo through PTY controls, labels, completion retention, and cleanup if supported; retain unchanged expensive heartbeat evidence rather than repeat the timing check.
- Review acceptance coverage separately from execution success and retain permitted factual evidence for unchanged behavior.

Candidate: `/home/vv/assignment/chat-generator`, base revision `e3cbe4d24a5e7d75b43763cbedab81301a3c9b18`, dirty working tree. Supervisor confirmed all candidate and acceptance writers paused; only record finalization permitted.
