"""Exercise the shipped demo through a real terminal and its Space/q bindings."""

import errno
import os
import pty
import select
import subprocess
import time
from pathlib import Path


def tmux(*args):
    return subprocess.check_output(['tmux', *args], text=True, stderr=subprocess.DEVNULL).strip()


def sessions():
    try:
        return set(tmux('list-sessions', '-F', '#{session_name}').splitlines())
    except subprocess.CalledProcessError:
        return set()


before = sessions()
master, slave = pty.openpty()
process = subprocess.Popen(['make', 'demo-offline-delivery'], stdin=slave, stdout=slave,
                           stderr=slave, env={**os.environ, 'TERM': 'xterm-256color'})
os.close(slave)
transcript = bytearray()
advanced = set()
session = None
finished = False
deadline = time.monotonic() + 90
try:
    while time.monotonic() < deadline:
        if select.select([master], [], [], 0.05)[0]:
            try:
                chunk = os.read(master, 65536)
            except OSError as error:
                if error.errno != errno.EIO:
                    raise
                chunk = b''
            transcript.extend(chunk)
        if process.poll() is not None:
            assert process.returncode == 0 and finished, transcript.decode(errors='replace')
            break
        candidates = {name for name in sessions() - before if name.startswith('chat-offline-')}
        if not candidates:
            continue
        assert len(candidates) == 1, candidates
        session = next(iter(candidates))
        step = tmux('show-options', '-v', '-t', session, 'status-right')
        if step.startswith('Complete:'):
            labels = set(tmux('list-panes', '-t', session, '-F', '#{@chat_label}').splitlines())
            assert labels == {'Server', 'Alice', 'Bob'}, labels
            assert len(advanced) == 7, advanced
            # Leave completion visible briefly, then exit through the documented key.
            time.sleep(0.5)
            os.write(master, b'q')
            finished = True
        elif step and step[0] in '1234567' and step not in advanced:
            print(step, flush=True)
            advanced.add(step)
            os.write(master, b' ')
    else:
        raise AssertionError('Demo control check timed out')
    assert sessions() == before, 'Demo leaked a session or changed an unrelated session'
    print('PASS: seven Space advances, stable pane labels, visible completion, q exit, session cleanup')
finally:
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
    if session and session in sessions():
        tmux('kill-session', '-t', session)
    os.close(master)
    Path(__file__).with_suffix('.terminal.log').write_bytes(transcript)
