"""Review-only real binary/WebSocket check; candidate files stay untouched."""

import asyncio
import json
import socket
import uuid
from pathlib import Path

from websockets.asyncio.server import serve


async def main():
    root = Path(__file__).resolve().parents[6]
    connections = asyncio.Queue()
    release = asyncio.Event()

    async def peer_handler(peer):
        await connections.put(peer)
        await release.wait()

    async with serve(peer_handler, "127.0.0.1", 0, ping_interval=None, max_queue=1) as server:
        port = server.sockets[0].getsockname()[1]
        process = await asyncio.create_subprocess_exec(
            str(root / "apps/chat/rust-client/target/debug/chat-rust"),
            "--url", f"ws://127.0.0.1:{port}/ws",
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        output = []
        changed = asyncio.Event()

        async def collect():
            while line := await process.stdout.readline():
                output.append(line.decode().rstrip("\n"))
                changed.set()

        collector = asyncio.create_task(collect())

        async def until(expected, start=0):
            async with asyncio.timeout(5):
                while not any(expected in line for line in output[start:]):
                    changed.clear()
                    await changed.wait()

        async def command(line):
            process.stdin.write((line + "\n").encode())
            await process.stdin.drain()

        async def login(stall=False):
            output_start = len(output)
            await command("/connect alice")
            peer = await asyncio.wait_for(connections.get(), 5)
            request = json.loads(await peer.recv())
            assert request["type"] == "login"
            if stall:
                peer.transport.get_extra_info("socket").setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4096)
                peer.transport.pause_reading()
            await peer.send(json.dumps({
                "type": "login_ok", "correlation_id": request["correlation_id"],
                "data": {"id": str(uuid.uuid4()), "name": "alice"},
            }))
            await until("✓ Logged in as alice", output_start)
            return peer

        try:
            await until("Chat ready")
            first = await login()
            await command("/drop-connection")
            await until("Disconnected")
            first.transport.abort()
            for _ in range(512):
                start = len(output)
                await command("/send bob " + "x" * 32768)
                await until("✓ Queued locally", start)

            start = len(output)
            peer = await login(stall=True)
            # Let the 16 MiB flush fill TCP buffers before delivering events.
            await asyncio.sleep(0.3)
            ids = []
            for number in range(200):
                message_id = str(uuid.uuid4())
                ids.append(message_id)
                await peer.send(json.dumps({
                    "type": "message_received", "data": {
                        "id": message_id, "sender_id": str(uuid.uuid4()),
                        "recipient_id": str(uuid.uuid4()), "sender_name": "bob",
                        "text": f"sustained event {number}", "client_sent_at": 0,
                        "server_received_at": "2026-11-08T12:00:00Z",
                        "recipient_received_at": None, "server_ack_received_at": None,
                    },
                }))
                if number % 10 == 0:
                    await peer.ping(f"ping {number}".encode())
                    await command("/status")
                await until(f"← bob: sustained event {number}", start)

            status_start = len(output)
            await command("/status")
            await until("Last heartbeat:", status_start)
            assert len([line for line in output[start:] if line.startswith("← bob: sustained event")]) == 200
            statuses = [line for line in output[start:] if line.startswith("Last heartbeat:")]
            assert len(statuses) >= 20 and statuses[-1] != "Last heartbeat: never", statuses
            assert len(set(statuses)) >= 2, statuses
            print(f"PASS: 200 incoming events and {len(statuses)} status blocks during stalled 16 MiB flush; heartbeat advanced.")
            # Resume transport and prove every deferred acknowledgment keeps its original ID.
            peer.transport.get_extra_info("socket").setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 2 * 1024 * 1024)
            peer.transport.resume_reading()
            acknowledgments = []
            sends = 0
            async with asyncio.timeout(20):
                while len(acknowledgments) < 200:
                    request = json.loads(await peer.recv())
                    if request["type"] == "ack":
                        acknowledgments.append(request["data"]["message_id"])
                    elif request["type"] == "send":
                        sends += 1
            assert acknowledgments == ids and sends == 512, (len(acknowledgments), sends)
            print("PASS: all 512 queued sends and 200 matching acknowledgments arrived after resume.")
            start = len(output)
            await command("/drop-connection")
            await until("Disconnected", start)
            await command("/quit")
            assert await asyncio.wait_for(process.wait(), 5) == 0
            errors = (await process.stderr.read()).decode()
            assert not errors, errors
            print("PASS: explicit drop and quit succeeded without stderr errors.")
        finally:
            if process.returncode is None:
                process.kill()
                await process.wait()
            await collector
            release.set()


if __name__ == "__main__":
    asyncio.run(main())
