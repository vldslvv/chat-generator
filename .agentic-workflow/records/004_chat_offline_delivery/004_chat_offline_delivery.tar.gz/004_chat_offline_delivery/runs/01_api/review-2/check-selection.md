# Independent API check selection

Selected from original sources before reading acceptance or candidate code.

- Scope: API task, WebSocket and storage contracts, API portions of verification.md, project engineering rules.
- Run Ruff and pytest unit/behavior suite against the candidate API.
- Inspect and exercise login validation, duplicate login, unauthorized send/ack, invalid envelopes, correlation echo and state-preserving errors through WebSocket behavior.
- Exercise accepted message payloads, offline pending replay, stored sender-name resolution, acceptance ordering across replay/new sends, self-send, acknowledgment ownership and immutable first acknowledgment timestamps.
- Verify storage through public operations: empty initial records, in-process persistence, record fields, pending filtering, atomic acknowledgment, acceptance order independent of client timestamps/IDs.
- Verify real Uvicorn heartbeat ping/timeout and disconnect/relogin cleanup through connection behavior.
- Reproduce delivery transport failure and sender acceptance failure through focused public-boundary fault checks; require retained pending records, logging and correct immediate/relogin delivery behavior.
- Review timestamp receive-time capture and malformed-client fallback at the wire boundary.
- Assess separate module responsibilities, real dependency coverage, meaningful independent expected outcomes, mock justifications and absence of production test hooks.
- Inspect Docker/dependency/run setup against FastAPI/Uvicorn one-worker, uv, Ruff and pytest constraints.
- Recheck prior findings only after independent initial selection.
