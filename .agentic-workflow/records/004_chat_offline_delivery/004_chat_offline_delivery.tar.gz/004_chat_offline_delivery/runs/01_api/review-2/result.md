# API reviewer 2 — result

- **Scope and candidate:** Fresh independent review of `apps/chat/api/` working tree against `e3cbe4d24a5e7d75b43763cbedab81301a3c9b18`; sources are `specs/spec_chat/project.md`, `task_order.md`, `tasks/01_api.md`, `contracts/websocket.md`, `contracts/storage.md` and API portions of `verification.md`; acceptance is this implementation's `tasks/01_api/acceptance.md`.
- **Role and status:** Reviewer; **FAIL** because F3 retains an unsupported self-send event-order requirement in a modified test; no remaining production defect was found.
- **Model routing:** Selected `agentic-workflow/policies/MODELS.md`, profile `careful`, Reviewer default; requested `gpt-6.1-sol` with `high` reasoning; observed settings unavailable.
- **Checks:** Selected original-source checks before reading acceptance or candidate code; see [check-selection.md](check-selection.md).
- **Execution:** `uv run pytest -q` from `apps/chat/api/`, with local-loopback escalation, exited 0: **59 passed, 76 dependency deprecation warnings in 48.34s**; this includes actual configured heartbeat timing, matching-pong handling, timeout and session cleanup.
- **Execution:** `uv run ruff check .` exited 0; `uv run ruff format --check .` exited 0 with 17 files formatted; `git diff --check -- apps/chat/api` from repository root exited 0.
- **Inspection:** Original task and contracts versus storage, sessions, handling, delivery, API, models, protocol, server, Dockerfile, dependencies, README and all API tests found adequate normal/offline flow, malformed request handling, timestamp fallback and receive-time capture, ownership checks, first-ack invariants, stored-name resolution, pending filtering and per-recipient ordering coverage.
- **Inspection:** Real TCP tests cover ordinary transport/lifecycle; ASGI send failures and barriers isolate deterministic transport/backpressure risks with real validation, storage, sessions and delivery; storage/handler public operations expose acknowledgment records that intentionally have no wire response; no production test hooks were found.
- **Findings and resolutions:** Prior F1 is fixed by the delivery `finally` block at `chat/api.py:82`; the independently run public ASGI regression verifies Bob receives the stored message even when Alice's acceptance transport fails, and logs preserve the cause/correlation.
- **Findings and resolutions:** Prior F2 is fixed at `tests/test_delivery.py:88–109`; sender acceptance may occur on either side of barrier release, and the final oracle checks old/old/new recipient notification order; permitted negative-control evidence fails at that delivery-order comparison.
- **Independent checks:** Read originals, acceptance, candidate, factual check/mock evidence and prior findings only; excluded plans, project memory, conversations/native logs and unrelated task history; kept the candidate unchanged and observed no reported candidate change during checking.
- **Coverage and blockers:** No execution blocker; Docker image execution and cross-language runners were outside this API task review; the test-audit skill's linked `/home/vv/docs/help/testing/writing-tests.md` was unavailable, while its applicable inline rules were read and applied.
- **Records:** Resolve succeeded with `python3 agentic-workflow/helpers/records.py resolve .agentic-workflow/records/004_chat_offline_delivery 01_api`; an earlier name-only invocation was corrected.
- **Usage:** Native usage counters and observed model settings unavailable.

## F3 — Low: Self-send test requires an unspecified event order

- **Requirement:** [WebSocket send and server events](/home/vv/assignment/chat-generator/specs/spec_chat/contracts/websocket.md) require a correlated acceptance and an uncorrelated incoming notification, while ordering guarantees apply to message delivery in server acceptance order; neither this contract nor [API Send](/home/vv/assignment/chat-generator/specs/spec_chat/tasks/01_api.md) orders those two events for a self-send.
- **Location:** [test_websocket.py:229](/home/vv/assignment/chat-generator/apps/chat/api/tests/test_websocket.py:229).
- **Expected:** The self-send/restart check should identify acceptance and notification by their event types and retain its payload/storage reset assertions, permitting either event order.
- **Observed:** The modified test asserts the first event is `message_accepted` and the second is `message_received`; a compliant implementation that delivers the self-notification before replying fails at line 230.
- **Evidence:** Source inspection of `test_new_server_discards_users_and_messages` lines 225–238; the candidate diff changes the old inverse ordering to the current implementation's ordering without a source requirement establishing that constraint.
- **Rule:** Engineering guidelines prioritize public behavior; the test-audit skill rejects implementation-coupled proof and requires behavior-preserving refactors to preserve test success; this repeats the same unsupported acceptance-order constraint addressed by prior F2.
- **Required repair:** Collect both self-send events, select each by `type`, and retain correlation, notification payload and restart-empty-state checks without asserting their relative arrival order.
- **Resolution:** Unfixed in this reviewed candidate.
