# Sender reply failure reproduction

- **Source:** `specs/spec_chat/contracts/websocket.md#delivery-behavior` requires immediate delivery attempts for online recipients.
- **Candidate:** API working tree after the initial 58-test pass, before review corrections.
- **Setup:** Import `connected` from `apps/chat/api/tests/test_delivery.py`; create one app, log Bob in through a normal ASGI transport, and log Alice in through an interceptor that raises `OSError('sender reply transport lost')` for `message_accepted`.
- **Action:** Have Alice send a message to Bob and wait 0.1 seconds for Bob's incoming event.
- **Observed:** Bob's receive times out; Alice's operation failure is logged with correlation; reconnecting Bob receives the retained message.
- **Expected:** Storing an accepted message for online Bob triggers an immediate delivery attempt even when returning the sender's acceptance fails.
- **Status:** Reproduced and forwarded to the independent reviewer and Supervisor; candidate unchanged during review.
