import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / "tests"))

from test_delivery import connected

from chat.api import create_app


async def scenario():
    async def fail_acceptance(event):
        if event["type"] == "message_accepted":
            raise OSError("sender acceptance transport lost")

    app = create_app()
    async with connected(app) as bob:
        await bob.login("bob")
        async with connected(app, fail_acceptance) as alice:
            await alice.login("alice")
            correlation = alice.request("send", {"recipient": "bob", "text": "must attempt"})
            try:
                await bob.receive(timeout=0.2)
            except TimeoutError:
                print(f"FAIL: online Bob receives no immediate delivery; correlation={correlation}")
            else:
                raise AssertionError("Reported defect was not reproduced")
    async with connected(app) as bob:
        await bob.login("bob")
        message = await bob.receive()
        assert message["type"] == "message_received"
        assert message["data"]["text"] == "must attempt"
        print("Confirmed stored pending message is delivered only after Bob reconnects")


asyncio.run(scenario())
