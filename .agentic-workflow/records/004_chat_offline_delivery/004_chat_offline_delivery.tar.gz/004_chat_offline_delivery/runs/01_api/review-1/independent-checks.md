# API independent check selection

Selected from original specifications before reading acceptance or candidate code.

- Run the API pytest suite through real WebSocket connections, including heartbeat and disconnect/relogin lifecycle.
- Run Ruff and inspect dependency/runtime configuration, including one-worker Uvicorn heartbeat defaults and Dockerfile.
- Inspect storage public operations for acceptance order, pending selection, first acknowledgment preservation, atomic timestamps and process-local lifetime.
- Inspect WebSocket validation for malformed envelopes, duplicate login, authentication, recipient ownership, timestamp fallback, correlation echo and unchanged state on rejection.
- Inspect offline delivery for stored pending messages, sender lookup without active sessions, each-login retry, flush/new-send ordering and failure logging without sender failure notification.
- Inspect tests against these contracts for independent expected outcomes, meaningful boundary ownership, mock justification and concrete missing coverage.
- Reproduce concrete suspected defects through public boundaries, keeping candidate code and configuration unchanged.

Scope: `apps/chat/api/` working tree against `e3cbe4d24a5e7d75b43763cbedab81301a3c9b18`.
