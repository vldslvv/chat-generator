# API reviewer — result

- **Scope and candidate:** Fresh independent review of `apps/chat/api/` working tree against `e3cbe4d24a5e7d75b43763cbedab81301a3c9b18`; sources are `specs/spec_chat/project.md`, `task_order.md`, `tasks/01_api.md`, `contracts/websocket.md`, `contracts/storage.md` and API portions of `verification.md`; applicable acceptance is `tasks/01_api/acceptance.md` under this implementation record.
- **Role and status:** Reviewer; **FAIL**, because F1 violates immediate delivery for online recipients; F2 adds an unjustified test constraint.
- **Model routing:** Selected `agentic-workflow/policies/MODELS.md`, profile `careful`, Reviewer default; requested `gpt-6.1-sol` with `high` reasoning; observed settings unavailable.
- **Checks:** Selected independent checks before reading acceptance or code, recorded in [independent-checks.md](independent-checks.md).
- **Execution:** `uv run pytest -q` from `apps/chat/api/`, with approved loopback escalation, exited 0: **58 passed, 76 dependency deprecation warnings in 48.40s**, including real configured heartbeat and cleanup.
- **Execution:** `uv run ruff check .` exited 0; `uv run ruff format --check .` exited 0 with 17 files formatted; `git diff --check -- apps/chat/api` from repository root exited 0.
- **Inspection:** Storage public operations preserve acceptance order, pending filters, immutable records and first acknowledgment timestamps; sessions isolate binding and cleanup; protocol retains correlation representation and timestamp fallback; runtime uses one worker and 20-second ping/timeout; Dockerfile and uv dependencies satisfy the task constraints.
- **Inspection:** ASGI failure/barrier transport substitutions have a justified distinct risk from real TCP tests; they exercise real validation, sessions, storage and delivery without production test hooks; storage/ack public-operation tests cover otherwise unobservable records.
- **Independent checks:** Original sources, applicable acceptance, candidate, permitted factual baseline/ordering logs and focused mock justification were read; plans, project memory, native logs and unrelated task history were excluded; no candidate edits were made and no candidate changes were reported during review.
- **Coverage and blockers:** Required existing API checks executed; passing tests omit sender acceptance transport failure; cross-language integration and Docker image execution are outside this task review; no execution blocker or cleanup failure occurred.
- **Usage:** Native usage counters unavailable.

## F1 — High: Sender reply failure suppresses delivery to an online recipient

- **Requirement:** `specs/spec_chat/tasks/01_api.md#send` and `contracts/websocket.md#delivery-behavior` require storage and an immediate delivery attempt when the recipient is online.
- **Location:** `apps/chat/api/chat/api.py:76`, preceding delivery at line 85.
- **Expected:** Once a message is stored for online Bob, an attempt to deliver it remains independent of whether Alice can receive `message_accepted`.
- **Observed:** The sender reply is awaited before delivery; an `OSError` converted to `WebSocketDisconnect` exits the handler before any delivery attempt, so Bob receives nothing until reconnecting despite staying online.
- **Reproduction:** From `apps/chat/api/`, run `uv run python /home/vv/assignment/chat-generator/.agentic-workflow/records/004_chat_offline_delivery/runs/01_api/review-1/reproduce_sender_reply_failure.py`; the script uses the existing public ASGI harness, fails only Alice's `message_accepted` transport and confirms Bob receives the stored message only after reconnecting.
- **Evidence:** The independently executed reproduction exited 0 after printing `FAIL: online Bob receives no immediate delivery` and `Confirmed stored pending message is delivered only after Bob reconnects`; stderr recorded `sender acceptance transport lost` with correlation ID and the exception at `api.py:76`.
- **Required repair:** Ensure the recipient delivery attempt runs after storage even when the sender reply fails, retain failure logging/session cleanup, and add one public-boundary regression for this failure path.
- **Resolution:** Unfixed in this reviewed candidate.

## F2 — Low: Ordering test requires an unspecified delay of sender acceptance

- **Requirement:** `specs/spec_chat/tasks/01_api.md#flush_messages` requires newer deliveries not to overtake pending messages; `contracts/websocket.md#send` defines acceptance as server receipt and storage; engineering guidelines and the test-audit skill require observable contract assertions without implementation-coupled proof.
- **Location:** `apps/chat/api/tests/test_delivery.py:88` in both barrier cases.
- **Expected:** Permit sender acceptance after storage while replay remains blocked, provided recipient delivery order remains old-first.
- **Observed:** The test asserts that Alice must receive no acceptance while Bob's login/replay transport is paused, thereby requiring storage/reply serialization with replay beyond the delivery-order contract; a compliant implementation that accepts now and schedules delivery after replay would fail this assertion.
- **Evidence:** Source inspection of lines 86–99 shows the stronger acceptance-timing assertion before the actual recipient-order comparison; the permitted ordering-control log also fails at that assertion, rather than the final delivery-order oracle.
- **Required repair:** Preserve deterministic concurrent arrival and the final old/old/new notification comparison while allowing acceptance either before or after barrier release; assess the negative control against the delivery-order assertion.
- **Resolution:** Unfixed in this reviewed candidate.
