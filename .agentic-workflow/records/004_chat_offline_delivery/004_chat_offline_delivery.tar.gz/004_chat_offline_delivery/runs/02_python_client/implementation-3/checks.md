# Python writer repair checks

- **Candidate:** `apps/chat/python-client/` working tree based on `e3cbe4d24a5e7d75b43763cbedab81301a3c9b18`.
- **Prior finding:** [Review 2](../review-2/result.md) reproduced sustained incoming-message reception blocked by acknowledgment writes; the reproduction failed twice before repair and its reads-enabled control passed.
- **Reviewer reproduction:** From `apps/chat/python-client/`, `uv run --frozen python ../../../.agentic-workflow/records/004_chat_offline_delivery/runs/02_python_client/review-2/backpressure_incoming.py` exited 0 and displayed all 3000 incoming messages before the peer resumed reading.
- **Control:** The same command with `--unblocked` exited 0 and displayed all incoming messages with reads enabled.
- **Prior regression:** `uv run --frozen python ../../../.agentic-workflow/records/004_chat_offline_delivery/runs/02_python_client/review-1/backpressure.py` exited 0 and displayed the event before the peer resumed reading.
- **Focused suite:** The shared backpressure test now bursts 3000 distinct incoming notifications during 16 MiB of queued sends for login and ordinary-send triggers; it verifies final-event display, heartbeat status, responsive commands, all deferred acknowledgment IDs and pre-resume receive timestamps, pong payload, abrupt cancellation and no stale controls on reconnect.
- **Full suite:** `uv run --frozen pytest -q` exited 0 with 40 passing tests; see [pytest.log](pytest.log).
- **Lint and format:** `uv run --frozen ruff check .` and `uv run --frozen ruff format --check .` exited 0 with all checks passing and all 15 files formatted.
- **Diff:** `git diff --check -- apps/chat/python-client` exited 0; inspected request transmission, timestamp placement, control queue lifetime, flush cancellation, reconnect ownership and unchanged terminal formatting.
- **Real dependencies and test audit:** Component tests use actual aiohttp peers, real CLI subprocesses and PTYs; the existing transport failure process now supplies the real pong operation through the production receive callback; no mock or test-only hook was added.
- **Shared checks:** Assembled integration must rerun against this repaired candidate through the Supervisor.
