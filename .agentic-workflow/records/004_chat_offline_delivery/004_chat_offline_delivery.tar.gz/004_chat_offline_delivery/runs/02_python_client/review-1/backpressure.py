"""Real CLI reproduction: incoming messages during a backpressured login flush."""

import asyncio
import sys
from uuid import uuid4

from aiohttp import web

sys.path.insert(0, "tests")
from test_cli import client, next_item, reply, server
from test_protocol import message_data


async def main():
    sockets = asyncio.Queue()
    release = asyncio.Event()
    connection_number = 0

    async def handler(request):
        nonlocal connection_number
        connection_number += 1
        number = connection_number
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        login = await ws.receive_json()
        await ws.send_json(reply("login_ok", login, {"id": str(uuid4()), "name": "alice"}))
        await sockets.put(ws)
        if number == 2:
            first = await ws.receive_json()
            assert first["type"] == "send"
            await ws.send_json({"type": "message_received", "data": {**message_data(), "sender_name": "bob", "text": "event during flush"}})
            # A slow receiving peer must not prevent its incoming notification
            # from being displayed by the client's independent receiver.
            await release.wait()
        async for _ in ws:
            pass
        return ws

    async with server(handler) as url:
        async with client(url) as cli:
            try:
                await cli.command("/connect alice")
                await next_item(sockets)
                await cli.until("Logged in as alice")
                await cli.command("/disconnect")
                await cli.until("Disconnected")
                for _ in range(512):
                    await cli.command("/send bob " + "x" * 32768)
                    await cli.until("Queued locally")
                print("Queued 512 valid messages (16 MiB total)", flush=True)
                await cli.command("/connect")
                await next_item(sockets)
                await cli.until("Logged in as alice")
                try:
                    async with asyncio.timeout(1):
                        await cli.until("event during flush")
                    print("PASS: incoming event displayed before server resumed reading", flush=True)
                except TimeoutError:
                    print("FAIL: incoming event not displayed during blocked queue flush", flush=True)
                    release.set()
                    await cli.until("event during flush")
                    print("Incoming event displayed only after server resumed reading", flush=True)
                    raise SystemExit(1)
            finally:
                release.set()


asyncio.run(main())
