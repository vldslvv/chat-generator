# Python independent review 2 — checks

Working directory for uv commands: `apps/chat/python-client/`.

- `uv run --frozen pytest -q`: exit 0, **40 passed in 4.36s**.
- `uv run --frozen ruff check .`: exit 0, all checks passed.
- `uv run --frozen ruff format --check .`: exit 0, 15 files already formatted.
- `uv run --frozen chat-python --help`: exit 0, required `--url URL` present.
- Repository-root `git diff --check -- apps/chat/python-client`: exit 0.
- `uv run --frozen python ../../../.agentic-workflow/records/004_chat_offline_delivery/runs/02_python_client/review-1/backpressure.py`: exit 0, incoming event displayed before server resumed reading.
- `uv run --frozen python ../../../.agentic-workflow/records/004_chat_offline_delivery/runs/02_python_client/review-2/backpressure_incoming.py`: exit 1 on two independent runs, output below.

```text
First incoming message displayed
FAIL: sustained incoming reception blocked before incoming 2999
Final incoming message displayed only after peer resumed reading
```

- The same command with `--unblocked` exited 0 in 0.63 seconds, with the first and final incoming messages displayed inside the same one-second observation window.

The reproduction uses the unchanged real CLI subprocess and real aiohttp WebSockets. It logs in, disconnects, queues 512 valid messages of 32 KiB through normal commands, and reconnects. After the peer receives the first queued send, it waits 0.2 seconds for outbound pressure, submits 3000 valid distinct incoming message notifications and a ping, and withholds outgoing-frame consumption. The CLI displays initial notifications but stalls before the final one. Releasing peer consumption permits the final notification to display. The control changes only whether peer consumption is withheld. The script's final edit clarifies the control's success text; execution logic is unchanged.

Manual inspection covered the full candidate modules, the full acceptance, public protocol/CLI/PTY/transport/queue tests, relevant diff, pyproject, uv lock presence and Docker entry point. Test peers control protocol order and operational faults through real sockets; they do not provide the client behavior being asserted. No production test-only hooks were found. The single-notification backpressure tests miss exhaustion of acknowledgment write capacity.

Cleanup completed without reported errors. Shared cross-language assembled checks remain owned by the Supervisor; Docker image execution was not run.
