"""Check sustained reception while acknowledgments share a backpressured socket."""
import asyncio
import sys
from uuid import uuid4

from aiohttp import web

sys.path.insert(0, "tests")
from test_cli import client, next_item, reply, server
from test_protocol import message_data


async def main():
    sockets = asyncio.Queue()
    release = asyncio.Event()
    if "--unblocked" in sys.argv:
        release.set()
    connection_number = 0

    async def handler(request):
        nonlocal connection_number
        connection_number += 1
        number = connection_number
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        login = await ws.receive_json()
        await ws.send_json(reply("login_ok", login, {"id": str(uuid4()), "name": "alice"}))
        await sockets.put(ws)
        if number == 2:
            assert (await ws.receive_json())["type"] == "send"
            await asyncio.sleep(0.2)
            for index in range(3000):
                await ws.send_json({"type": "message_received", "data": {**message_data(), "id": str(uuid4()), "sender_name": "bob", "text": f"incoming {index}"}})
            await ws.ping(b"after-messages")
            await release.wait()
        async for _ in ws:
            pass
        return ws

    async with server(handler) as url:
        async with client(url) as cli:
            try:
                await cli.command("/connect alice")
                await next_item(sockets)
                await cli.until("Logged in as alice")
                await cli.command("/disconnect")
                await cli.until("Disconnected")
                for _ in range(512):
                    await cli.command("/send bob " + "x" * 32768)
                    await cli.until("Queued locally")
                await cli.command("/connect")
                await next_item(sockets)
                await cli.until("Logged in as alice")
                await cli.until("incoming 0")
                print("First incoming message displayed", flush=True)
                try:
                    async with asyncio.timeout(1):
                        await cli.until("incoming 2999")
                    print("PASS: all incoming messages displayed" + (" with peer reads enabled" if "--unblocked" in sys.argv else " before peer resumed reading"), flush=True)
                except TimeoutError:
                    print("FAIL: sustained incoming reception blocked before incoming 2999", flush=True)
                    release.set()
                    await cli.until("incoming 2999")
                    print("Final incoming message displayed only after peer resumed reading", flush=True)
                    raise SystemExit(1)
            finally:
                release.set()


asyncio.run(main())
