# Independent criteria

Chosen from original requirements before acceptance and candidate inspection.

- Verify CLI parsing, all command states, idempotent lifecycle operations, remembered usernames, and specified status fields against `contracts/cli.md`.
- Verify queue FIFO, sending-user isolation, fresh correlations and transmit-time UTC timestamps, acceptance-only removal, retention after errors/disconnection, correlation reset, and absence of retries on the same connection.
- Verify login and message protocol types preserve UUID, UTC, zero, and null wire alternatives.
- Verify incoming messages, named-sender display, receive-time timestamps, acknowledgments, heartbeat pong/time tracking, and incoming processing during terminal input and queue flushing.
- Verify each local/server/operational failure appears once on stderr with cause and available correlation ID, usable reconnect instructions, and no normal exception class names.
- Verify terminal prompts, output blocks, unfinished input/cursor restoration, and self-message event ordering.
- Verify required Python tooling, dependency lock, module responsibilities, Docker entry point, and public behavior test value.
- Run component tests and reproduce prior backpressure finding using a real socket peer; inspect shared scenario coverage with assembled execution owned by Supervisor.

Sources: `specs/spec_chat/project.md`, `tasks/02_python_client.md`, `tasks/shared/client.md`, `contracts/cli.md`, `contracts/websocket.md`, `contracts/storage.md`, `verification.md`, and `offline_delivery_test_plan.md`.
