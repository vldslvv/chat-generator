# Python client repair checks

- **Candidate:** `apps/chat/python-client/` working tree based on `e3cbe4d24a5e7d75b43763cbedab81301a3c9b18`.
- **Prior finding:** [Review 1 F1](../review-1/result.md) reproduced event reception blocked by a backpressured reconnect queue flush; its real-peer reproduction exited 1 before repair.
- **Reviewer reproduction:** From `apps/chat/python-client/`, `uv run --frozen python ../../../.agentic-workflow/records/004_chat_offline_delivery/runs/02_python_client/review-1/backpressure.py` exited 0 and displayed the event before the peer resumed reading.
- **Focused regression:** `uv run --frozen pytest tests/test_outgoing_queue.py -q` exited 0 with 3 passing cases, including login and ordinary-send triggers with 16 MiB queued against a slow real peer; observed incoming display, heartbeat state, responsive status and abrupt disconnect before releasing peer backpressure.
- **Full suite:** `uv run --frozen pytest -q` exited 0 with 40 tests passing; see [pytest.log](pytest.log).
- **Lint and format:** `uv run --frozen ruff check .` and `uv run --frozen ruff format --check .` exited 0 with all checks passing and all 15 files formatted.
- **Diff:** `git diff --check -- apps/chat/python-client` exited 0; inspected flush task startup, cancellation, await, failure abort, disconnect state reset and protocol trigger boundaries.
- **Real dependencies and test audit:** Both backpressure cases use the CLI subprocess and actual aiohttp sockets; the peer stops consuming outgoing frames, exposing independent command and reception responsiveness; no transport mocks or production test seams were added.
- **Shared checks:** Assembled integration must rerun against the repaired candidate through the Supervisor.
