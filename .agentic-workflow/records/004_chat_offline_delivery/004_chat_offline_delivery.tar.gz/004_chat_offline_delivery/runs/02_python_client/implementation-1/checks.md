# Python client implementation checks

- **Candidate:** `apps/chat/python-client/` in the working tree based on `e3cbe4d24a5e7d75b43763cbedab81301a3c9b18`.
- **Baseline regression:** Before production edits, `uv run --frozen pytest tests/test_outgoing_queue.py -q` exited 1 after an offline send failed to produce `✓ Queued locally` within four seconds.
- **Behavior checks:** From `apps/chat/python-client/`, `uv run --frozen pytest -q` exited 0 with 38 passing tests; see [pytest.log](pytest.log).
- **Lint:** From `apps/chat/python-client/`, `uv run --frozen ruff check .` exited 0 with `All checks passed!`.
- **Format:** From `apps/chat/python-client/`, `uv run --frozen ruff format --check .` exited 0 with all 15 files formatted.
- **Diff:** `git diff --check -- apps/chat/python-client` exited 0; inspected all changed production modules and the new outgoing queue module and test against the CLI queue lifecycle and WebSocket correlation contracts.
- **Test audit:** The new subprocess scenario owns queue retention, user isolation, FIFO transmission, acceptance matching, errors and fresh reconnect attempts; the existing CLI test now consumes retained sends instead of asserting the obsolete single-send restriction.
- **Real dependencies:** Component behavior tests use actual aiohttp WebSocket connections, subprocess terminal pipes and a real PTY; no production test hooks or mocked queue/transport are added.
- **Peer scope:** Programmable aiohttp peers control acceptance ordering, validation errors and abrupt closure; API storage semantics and cross-language delivery remain covered by the API suite and Supervisor's shared integration run.
- **Technology inspection:** Existing asyncio/aiohttp transport, Pydantic payloads, uv manifest/lock and Docker interactive `chat-python` entry point with required `--url` remain present.
