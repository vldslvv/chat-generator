# 01_api — plan

- **Request and scope:** Reconcile the retained API with the revised offline delivery specification in plan-review mode; own `apps/chat/api/` and this task's records only.
- **Acceptance:** [acceptance.md](acceptance.md) covers the API task and shared contracts.
- **Sources and dependencies:** Read `specs/spec_chat/project.md`, `tasks/01_api.md`, `contracts/websocket.md`, `contracts/storage.md`, `verification.md`, and `task_order.md`; apply `agentic-workflow/policies/GUIDELINES.md` and `CHECKS.md`; this task has no prerequisites.
- **Approach:** Add pending lookup in storage, accept sends to offline users, resolve notification sender names from storage, and coordinate login replay with new sends using a recipient lock in delivery state; send acceptance after storage and before attempting delivery; retain module boundaries and plain record models.
- **Target and paths:** Keep the FastAPI/Uvicorn one-worker API in `apps/chat/api/`; save evidence under `runs/01_api/implementer/`; Supervisor owns shared integration, Makefile, and chat README.
- **Checks:** Run the full pytest suite against real local TCP and heartbeat timing, Ruff lint and format checks, and inspect the diff; test storage filtering/order, offline sender replay, acknowledgment exclusion, failure retention/reconnect, and coordinated delivery at the ASGI transport boundary; obtain fresh independent review after pausing writers.
- **Memory:** Read `.agentic-workflow/memory/index.md` and `entries/chat-api.md`.
