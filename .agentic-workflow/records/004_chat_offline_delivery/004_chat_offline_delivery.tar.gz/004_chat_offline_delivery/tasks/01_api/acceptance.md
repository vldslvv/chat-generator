# 01_api — acceptance

- **Request, sources and scope:** Implement `specs/spec_chat/tasks/01_api.md` against `project.md`, `contracts/websocket.md`, and `contracts/storage.md`; preserve existing validation, heartbeat, timestamp, logging, and process-lifetime behavior under the engineering guidelines.
- **Prerequisites:** `specs/spec_chat/task_order.md` lists no prerequisites for `01_api.md`.
- **Target and paths:** API source and checks live in `apps/chat/api/`; evidence lives in `runs/01_api/implementer/`.
- **Contracts:** `/ws` accepts correlated JSON login, send, and ack requests; successful login returns the user; accepted sends return stored message fields; recipient notifications add only `sender_name`; valid acknowledgments have no reply; errors preserve valid correlation IDs and leave state unchanged, as defined by `contracts/websocket.md`; storage operations follow `tasks/01_api.md#storage` and `contracts/storage.md`.

| Requirement ID | Source / contract | Check scenario and pass rule |
|---|---|---|
| API-01 | API Login; WebSocket connection behavior | Connect, reject invalid and repeated logins, confirm connection remains usable and duplicate active user is refused; reconnect after close and recover the same user. |
| API-02 | API Send; WebSocket delivery behavior | Create then disconnect recipient, send multiple messages, and receive immediate correlated acceptance; unknown recipients remain rejected. |
| API-03 | API flush_messages; WebSocket delivery behavior | Reconnect recipient after sender disconnects and receive pending messages once in acceptance order, independently of timestamps and UUIDs, with names resolved from stored users. |
| API-04 | API Storage; Data contract | Through public storage operations, verify pending lookup filters by recipient and null server acknowledgment, retains acceptance order, and keeps acknowledged records without adding queue fields. |
| API-05 | API flush_messages | Pause an actual ASGI login reply or replay send, submit a newer message concurrently, then release transport; verify recipient receives old pending messages before the newer message. |
| API-06 | API Acknowledge and Timestamps | Reject unauthorized, unknown, malformed, and unauthenticated acknowledgments without mutation; preserve valid UTC or fallback zero values and first event timestamps atomically; reconnect after acknowledgment and observe no replay. |
| API-07 | API delivery failure; project logging | Fail an ASGI delivery transport after storage, observe acceptance and logged cause/correlation, retain pending storage, then reconnect recipient and recover the message without sender failure notification or established-connection retry. |
| API-08 | API Send and Timestamps; Data contract | Exercise text validation, empty text, forged fields, missing/malformed/valid client times, server receive times, authenticated sender derivation, and self delivery using real TCP. |
| API-09 | WebSocket envelope and connection behavior | Preserve correlation representation, omit invalid IDs and notification IDs, keep invalid requests usable, and observe real 20-second ping and matching-pong timeout cleanup. |
| API-10 | API Storage; project failure logging and constraints | Restart server to empty collections; verify stderr rejection/transport causes, required modules/tooling/Dockerfile, full pytest and Ruff checks. |
| API-11 | API Send; WebSocket delivery behavior | Fail the sender's acceptance-reply transport after storage while the recipient remains online; verify immediate recipient delivery and logging of the sender failure with correlation. |

- **Shared/regression/final checks:** Follow `specs/spec_chat/verification.md` API scenarios; run full API pytest, Ruff check and format check; shared cross-language offline runners belong to Supervisor.
- **Limits and decisions:** Deterministic ASGI transport failures and barriers exercise delivery failures and ordering without socket timing races; real local TCP tests cover ordinary login/replay; no production-only testing hooks or external dependencies are needed.
- **Correction history:** Independent review 1 identified missing sender-reply failure coverage and an unspecified sender-acceptance timing assertion; API-11 adds the missing source-derived case, and API-05 permits either sender-acceptance timing while preserving recipient order.
