# 02_python_client — plan

- **Request and scope:** Reconcile the existing Python client with the revised chat specification in plan-review mode.
- **Acceptance:** Apply [acceptance.md](acceptance.md).
- **Sources and dependencies:** Use `specs/spec_chat/tasks/02_python_client.md`, `tasks/shared/client.md`, `contracts/cli.md`, `contracts/websocket.md`, `contracts/storage.md`, and `project.md`; API prerequisite accepted at `runs/01_api/review-3/result.md`.
- **Approach:** Keep one ordered queue in client state; encapsulate insertion, flushing and acceptance matching in a queue module; replace the single pending-send field with entry correlation IDs; flush the authenticated user's unsent entries after login and sends; retain failed attempts until disconnect resets correlation IDs.
- **Target and paths:** Own `apps/chat/python-client/` and this task's records; leave API, Rust, shared harness and app documentation to their owners.
- **Checks:** Extend subprocess CLI behavior checks with real aiohttp WebSocket peers for offline FIFO, multiple in-flight sends, selective matching, errors, disconnect and switching users; retain protocol, PTY presentation, heartbeat and transport failure regressions; run pytest and Ruff; inspect the diff; request fresh review after pausing the boundary.
- **Memory:** Read `.agentic-workflow/memory/index.md`; no entry applies to Python queue work.
