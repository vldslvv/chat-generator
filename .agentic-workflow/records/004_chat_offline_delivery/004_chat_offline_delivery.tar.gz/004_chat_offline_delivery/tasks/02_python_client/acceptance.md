# 02_python_client — acceptance

- **Request, sources and scope:** Implement `specs/spec_chat/tasks/02_python_client.md` and `tasks/shared/client.md` against the linked CLI, WebSocket, storage and project contracts.
- **Prerequisites:** Apply `specs/spec_chat/task_order.md`; the API prerequisite has passing independent review evidence at `runs/01_api/review-3/result.md`.
- **Target and paths:** Candidate is `apps/chat/python-client/`; evidence belongs under `runs/02_python_client/`.
- **Contracts:** Apply `specs/spec_chat/contracts/cli.md` for commands, queue state, status, failures and presentation, and `contracts/websocket.md` for requests, correlations, timestamps, notifications and acknowledgments.

| Requirement ID | Source / contract | Check scenario and pass rule |
|---|---|---|
| PY-01 | CLI Commands, Client state, Status | Start the subprocess, exercise connection commands, successful and rejected login, status, EOF and quit against a real WebSocket peer; verify idempotence, remembered name, reset session fields, retained heartbeat, explicit reconnect and closure. |
| PY-02 | CLI Outgoing queue, Behavior | Establish and disconnect Alice; enqueue messages for multiple recipients with original spacing; verify local queue output without transmission; reconnect and observe individual requests in FIFO order with fresh UUIDs and current UTC timestamps. |
| PY-03 | CLI Outgoing queue, Client state | Send several entries without replies; accept entries out of order, reject one, send another and disconnect; verify matching acceptance alone removes entries and errors cause no same-connection retry; reconnect and observe only retained entries with fresh IDs. |
| PY-04 | CLI Outgoing queue | Retain Alice messages and connect as Bob; verify Alice entries remain unsent while Bob sends normally, then reconnect Alice and observe her retained entries. |
| PY-05 | WebSocket Envelope, Server events; shared client Behavior | Exercise matching and unexpected replies, incoming and self messages, acknowledgment, ping/pong, malformed frames and transport failure; verify names, original text, capture-before-display timestamps, quiet heartbeat and actionable correlated stderr errors. |
| PY-06 | CLI Terminal presentation | Exercise a real PTY with partially typed input and cursor movement; verify event blocks preserve completed output and restore input/cursor, and command output remains grouped with blank separators. |
| PY-07 | Python technology constraints | Run pytest and Ruff; inspect asyncio/aiohttp/Pydantic interfaces, uv files and Docker entry point supporting `--url` and interactive input. |
| PY-08 | Shared client Acceptance; verification Offline delivery | Supervisor runs the shared headless offline scenario with both language assignments and real API; verify local queueing, reconnect acceptance and offline recipient delivery. |

- **Shared/regression/final checks:** Preserve the existing protocol, CLI, terminal, transport and PTY suites; run shared client integration after both client owners finish.
- **Limits and decisions:** Component behavior tests use a programmable real aiohttp WebSocket peer to select reply ordering and failure timing; API persistence and cross-language interoperability are checked by the API suite and shared integration harness.
