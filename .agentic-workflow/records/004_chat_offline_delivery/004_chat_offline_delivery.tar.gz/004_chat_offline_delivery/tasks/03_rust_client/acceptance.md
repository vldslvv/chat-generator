# 03_rust_client — acceptance

- **Request, sources and scope:** Implement `specs/spec_chat/tasks/03_rust_client.md` and its referenced shared client behavior under the engineering guidelines; preserve command, protocol, and terminal behavior while supporting offline delivery.
- **Prerequisites:** `specs/spec_chat/task_order.md`; accepted API prerequisite at `runs/01_api/review-3/result.md`.
- **Target and paths:** `apps/chat/rust-client/`; evidence in `runs/03_rust_client/`.
- **Contracts:** `specs/spec_chat/contracts/cli.md` defines command inputs, output, errors, local state, and queue lifecycle; `specs/spec_chat/contracts/websocket.md` defines envelopes, wire types, responses, notifications, heartbeat, and acknowledgment.

| Requirement ID | Source / contract | Check scenario and pass rule |
|---|---|---|
| RC1 | CLI Commands, Client state, Status | Start disconnected; validate malformed commands and sends; connect and disconnect idempotently; show every status field; retain only successfully remembered names and heartbeat across disconnects. |
| RC2 | CLI Outgoing queue and Behavior | After successful login disconnect, enqueue messages to different recipients and preserve text; show local queueing immediately; reconnect and observe FIFO individual sends with current UTC timestamps and fresh UUIDs; acceptance appears only after matching replies. |
| RC3 | CLI Outgoing queue and Client state lifecycle | Keep unaccepted and server-rejected entries; ignore unmatched acceptance; process later sends without retransmitting old attempts on that connection; disconnect and retry retained messages with fresh IDs; an old attempt's acceptance cannot remove a current attempt. |
| RC4 | CLI Outgoing queue sender ownership | Retain Alice's entries through a login as Bob; transmit only Bob's messages while Bob is authenticated; reconnect as Alice and transmit Alice's entries in insertion order. |
| RC5 | WebSocket Envelope, Shared types, Client requests, Server events | Validate login/send/ack UUID envelopes and zero/null timestamp alternatives; display sender name and original content before acknowledgment; keep acceptance independent of delivery order; log correlated errors once. |
| RC6 | CLI Terminal presentation; shared client Behavior and Acceptance | Preserve prompt, cursor, unfinished Unicode input, completed output blocks, blank lines, readable stderr diagnostics, silent matching pong replies, and usable commands after detected connection loss without automatic reconnect; stall a peer during a large reconnect flush and require incoming display, heartbeat status, and commands to remain responsive. |
| RC7 | Rust Constraints | Keep Tokio, tokio-tungstenite, Serde, Cargo lockfile, and the separate interactive Dockerfile; pass Cargo tests, format, and clippy checks. |
| RC8 | Verification Offline delivery | Supervisor runs the same-process Alice/Bob offline scenario in both language assignments through the shared headless and tmux harness, confirming local queue output, delayed acceptance, and delivery while senders remain disconnected. |

- **Shared/regression/final checks:** Preserve existing CLI/PTY public behavior checks and wire-type checks; run shared real-API integration after both clients are available; inspect implementation and check diffs against the linked contracts.
- **Limits and decisions:** Scripted WebSocket peers control response IDs, errors, and connection loss over real TCP; they do not replace the required assembled real-API offline scenarios.
