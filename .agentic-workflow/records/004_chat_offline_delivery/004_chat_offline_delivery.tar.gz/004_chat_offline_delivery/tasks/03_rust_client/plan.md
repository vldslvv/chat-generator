# 03_rust_client — plan

- **Request and scope:** Reconcile the Rust client with the revised offline delivery specification in plan-review mode; own only `apps/chat/rust-client/` and this task's records.
- **Acceptance:** [acceptance.md](acceptance.md).
- **Sources and dependencies:** `specs/spec_chat/tasks/03_rust_client.md`, `tasks/shared/client.md`, `contracts/cli.md`, `contracts/websocket.md`, `project.md`, and `verification.md`; API prerequisite accepted at `runs/01_api/review-3/result.md`.
- **Approach:** Add one outgoing FIFO with sender names and attempt correlations; encapsulate queue operations and flushing in a queue module; retain errors and interrupted attempts until correlated acceptance; reset attempts only on disconnect; flush the authenticated user's entries after login and new sends; schedule writes through an independent transport writer so backpressure preserves input and event processing, and encode send timestamps at transmission.
- **Target and paths:** Implement in `apps/chat/rust-client/`; save evidence under `runs/03_rust_client/implementation/`.
- **Checks:** Extend CLI subprocess tests over real WebSocket sockets for offline retention, ordered attempts, user switching, unmatched and delayed acceptance, fresh correlations, and no same-connection retry; retain presentation, heartbeat, status, and failure checks; run `cargo test --locked`, `cargo fmt --check`, and `cargo clippy --all-targets --locked -- -D warnings`; inspect the diff; delegate both-language assembled scenarios to Supervisor's shared harness after both clients are ready.
- **Memory:** Read `.agentic-workflow/memory/index.md`; its API-only entry does not govern the client.
